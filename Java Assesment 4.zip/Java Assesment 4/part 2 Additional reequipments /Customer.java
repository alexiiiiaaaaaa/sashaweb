
/**
 * Write a description of class Customer here.
 * 
 * @author
 * @version
 */
public class Customer
{
    private int customerNumber;
    private String customerName;
    private String customerPostCode;

    /**
     * Constructor for objects 
     */
    public Customer()
    {
        // initialise instance variables
        customerNumber = 0;
        customerName = "";
        customerPostCode ="";
    }
    
    /**
     *Print all customer details 
     */
    public void printCustomer()
    {
        System.out.println("**********************************");
        System.out.println("customer Number: "+ customerNumber);
        System.out.println("customer Name: "+ customerName);
        System.out.println("customer PostCode: "+ customerPostCode);
        System.out.println("**********************************");
    }

    /**
     * accessor method     
     * @return     customerNumber
     */
    public int getCustomerNumber()
    {
        return customerNumber;
    }

    /**
     * accessor method     
     * @return     customerNumber
     */
    public String getCustomerName()
    {
        return customerName;
    }

    /**
     * accessor method     
     * @return     customerPostCode
     */
    public String getCustomePostCode()
    {
        return customerPostCode;
    }
    
    /**
     * set up the variable  
     * @param  customerNumber
     */
    public void setCustomerNumber(int newNumber)
    {
        customerNumber = newNumber;
    }
    /**
     * set up the variable  
     * @param  customerName
     */
    public void setCustomerName(String newName)
    {
        customerName = newName;
    }
    
    /**
     * set up the variable  
     * @param  customerPostCode 
     */
    public void setCustomerPostCode(String newPostCode)
    {
        customerPostCode = newPostCode;
    }


}
