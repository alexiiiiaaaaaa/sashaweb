
/**
 * @author Anna-Oleksandra Chanieva 2616332
 * @version 1.0
 */

public class Booking
{
    private int bookingNumber;
    private boolean paid;
    //private Vehicle vehicle1;
    private Customer customer1;
    //private Car car1;
    //private Van van1;

    /**
     * Constructor for objects
     */
    public Booking()
    {
        // initialise instance variables
        bookingNumber = 0;
        paid = false;
    }
     
    /**main method
     * 
     */
      public static void main(String [] args)
    {
        //create an instance of a vehicle
        Vehicle vehicle1 = new Vehicle(); 
        // create an instance of a car with 4 seats
        Car car1 = new Car(4);
         // create an instance of a van with size = 10
        Van van1 = new Van(10);

        /** 
         * do/while loop to organize a menu for a vehicle selection
         * **/
        System.out.println("Plese select car(c, C) or van(v, V): ");
        boolean keeplooping = true;
        do {
            char selectVehicle = Genio.getCharacter();
            switch (selectVehicle) {
                case 'c':
                case 'C':
                    System.out.println("You have selected a car");
                    vehicle1 = car1;
                    keeplooping=false;
                    break;
                case 'v':
                case 'V':
                    System.out.println("You have selected a van");
                    vehicle1 = van1;
                    keeplooping=false;
                    break;
            
                default:
                System.out.println("Please enter c, C - for a car or  v, V - for a van! ");
                    break;
            }
        } while(keeplooping == true);

        // make a booking for a selected vechicle 
        Booking Booking1 = new Booking();
        Booking1.makeBooking(vehicle1);
    }

    /**
     * print booking details
     * Method was modified to get theVehicle object as an argument
     */
    public void printBooking(Vehicle theVehicle)
    {
       System.out.println("##############################################");
       System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
       System.out.println("booking Details");
       customer1.printCustomer();
       System.out.println("vehicle details");
       theVehicle.printVehicle();
       System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
       System.out.println("payment details");
       System.out.println("cost of vehicle " + theVehicle.getCost());
       if (paid){
             System.out.println("balance paid ");
            }
            else {
                System.out.println("balance outstanding");
            }
        System.out.println("##############################################"); 
    }

    /**
     * place a booking 
     * Method was modified to get theVehicle object as an argument
     */
    public void makeBooking(Vehicle theVehicle)
    {

        //check vehicle availability 
        if(theVehicle.getAvailable()== false)
        {
            System.out.println("Sorry but the vehicle is already on hire");
        }
        else 
        {
            System.out.println("Vehicle is available for hire");
            //call the method to get the customer details
            customerDetails();
            // sort out the payment
            payment(theVehicle);
            
            //print out booking details
            printBooking(theVehicle);
       }
       // set vehicle availability to false
       theVehicle.setAvailable(false);  
    }

    /**
     * input the customer details 
     */
    public void customerDetails()
    {
      // create a new instance of the customer class
        customer1 = new Customer();
        System.out.println("Please enter the customer number");
        int cusNum = Genio.getInteger(); 
        System.out.println("Please enter the customer name");
        String cusName = Genio.getString(); 
        System.out.println("Please enter the customer PostCode");
        String cusPC = Genio.getString(); 
        
        customer1.setCustomerNumber(cusNum);
        customer1.setCustomerName(cusName);
        customer1.setCustomerPostCode(cusPC);
    }

     /**
     * sort out the payment wiht the customer
     * set paid to true or false
     * Method was modified to get theVehicle object as an argument
     */
    public void payment(Vehicle theVehicle)
    {
        System.out.println("the cost of htis vehicle is �"+ theVehicle.getCost());
        System.out.println("has the customer paid? Y/N");
        String YN = Genio.getString();
        if (YN =="Y")
        {
            paid = true;
        }
        else 
        {
            paid = false;
        }
    }  
}
