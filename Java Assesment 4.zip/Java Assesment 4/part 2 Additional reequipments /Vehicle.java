
/**
 * Write a description of class vehicle here.
 * 
 * @author
 * @version
 */
public class Vehicle
{
	private String colour;
	private boolean available;
	private String make;
	private float cost;
    private String reg;

    /**
	 * Constructor for objects 
	 */
	public Vehicle()
	{
		// initialise instance variables
		reg = "ST07 JAVA";
		colour = "BLUE";
		available = true;
		make = "FORD";
		cost = 20.00f;
	}

    /**
	 * print all vehicle details 

	 * @return   cost 
	 */
	public void printVehicle()
	{
	    System.out.println("reg " + reg);
	    System.out.println("colour " + colour);
	    System.out.println("make " + make);
	 }

    /**
	 * accessor method 
	 * 
	 * @return   reg 
	 */
	public String getReg()
	{
		return reg;
	}

    /**
	 * accessor method 
	 * 
	 * @return   colour 
	 */
	public String getColour()
	{
		return colour;
	}

    /**
	 * accessor method 
	 * 
	 * @return   available 
	 */
	public boolean getAvailable()
	{
		return available;
	}
	
    /**
	 * accessor method 
	 * 
	 * @return   cost 
	 */
	public float getCost()
	{
		return cost;
	}

    /**
	 * set the global variable 
	 * 
	 * @param  reg
	 */
	public void setReg(String newReg)
	{
		 reg = newReg;
	}
	
    /**
	 * set the global variable 
	 * 
	 * @param  available
	 */
	public void setAvailable(boolean newAvailable)
	{
		 available = newAvailable;
	}
	
	/**
	 * set the global variable 
	 * 
	 * @param  make 
	 */
	public void setMake(String newMake)
	{
		 make = newMake;
	}
    
    /**
	 * set the global variable 
	 * 
	 * @param  colour
	 */
	public void setColour(String newColour)
	{
		 colour = newColour;
	}

    /**
	 * accessor method 

	 * @return   make 
	 */
	public String getMake()
	{
		return make;
	}
	
    /**
	 * set the global variable 
	 * 
	 * @param  cost
	 */
	public void setCost(float newCost)
	{
		 cost = newCost;
	}


	
}
