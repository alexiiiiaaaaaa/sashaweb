/** 
 * Car is a subclass of Vehile class, which contains additional attributes 'numberOfSeats'
 * **/
public class Car extends Vehicle {
    private int numberOfSeats;

    /** 
     * Car class constructor which initializes numberOfSeats of the car
     * **/
    public Car (int theSeats)
    {
        super();
        this.numberOfSeats=theSeats;
    }

    /** 
     * printVehicle() - prints all vehicle details including car numberOfSeats.
     * @return void 
     * **/
    public void printVehicle()
    {
       super.printVehicle();
       System.out.println("number of seats of the car: " + numberOfSeats); 
    }
    

}
