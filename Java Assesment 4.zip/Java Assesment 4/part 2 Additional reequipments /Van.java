/** 
 * Van is a subclass of Vehile class, which contains additional attributes 'size'
 * **/
public class Van extends Vehicle {
    private int size;

    /** 
     * Van class constructor which initializes size of the van
     * **/
    public Van(int theSize)
    {
        super();
        this.size = theSize;
    }

    /** 
     * printVehicle() - prints all vehicle details including van size
     * @return void 
     * **/
    public void printVehicle()
    {
        super.printVehicle();
        System.out.println("The size of the van: " + size);
    }
}
