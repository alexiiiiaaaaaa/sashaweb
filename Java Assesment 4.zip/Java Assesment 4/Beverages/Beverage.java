/**
 * Assigment 4, part 1: Bevereges 
 * @author Anna-Oleksandra Chanieva 2616332
 * @version 1.0
 *  **/

 /** 
  * Beverage - is the super class, it contains main properties: size, cost and name
  **/
public class Beverage {
    private String name;
    private int cost;
    private int size;

    /** 
     * this is the constractor of the class, witout arguments
     * **/
    public Beverage()
    {
        
    }
    
    /** 
     * This is a constractor which initializes all class fields: name, cost, size
     * **/
    public Beverage(String theName, int theCost, int theSize)
    {
        this.name = theName;
        this.cost = theCost;
        this.size = theSize;
    }

    /** 
     * PrintAttributes() - method which prints attributes such as name, cost and size 
     * @return void 
     * **/
    public void PrintAttributes()
    {
        System.out.println("Beverage name is: " + name);
        System.out.println("Beverage cost is: " + cost);
        System.out.println("Beverage size is: " + size);
    }

    /** 
     * PrintCost() - method which prints cost of drink 
     * @return void 
     * **/
    public void PrintCost()
    {
        System.out.println("The price for chosen drink: " + cost);
    }

}
