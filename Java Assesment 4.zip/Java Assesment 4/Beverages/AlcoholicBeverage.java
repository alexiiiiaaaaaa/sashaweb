/** 
 * AlcoholicBeverage - this is a subclass which inherits Beverage class and extend it with 'strength' field.
 * **/
public class AlcoholicBeverage extends Beverage {
    private String strength;

    /** 
     * this is a constractor of AlcoholicBeverage
     * **/
    public AlcoholicBeverage()
    {
        super();
    }
    
    /** 
     * AlcoholicBeverage - this a constructor which initializes all class fields: name, cost, size, strength.
     * name,cost, size are initialized by the call to a super class constructor.
     * **/
    public AlcoholicBeverage(String theName, int theCost, int theSize, String theStrength)
    {
        super(theName, theCost, theSize);
        this.strength = theStrength;
    }
    
    /**
     * PrintAttributes() - method which prints attributes such as name, cost, size and strength
     * name,cost, size are printed by the call to a PrintAttributes() from the super class.
     * @return void  
     *  **/
    public void PrintAttributes()
    {
        super.PrintAttributes();
        System.out.println("The alcohol is strength: " + strength);
    }
}
