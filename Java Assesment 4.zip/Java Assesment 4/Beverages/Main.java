import java.io.IOException;

/** 
 * Main class which contain method main() to execute the programm
 * **/
public class Main {
    public static void main(String[] args) {

        // bv1 - instance of Beverage class 
        Beverage bv1 = new Beverage("Juice",  100, 200);

        // mBev - instance of MilkBeverage class 
        MilkBeverage mBev = new MilkBeverage("Milk Shake", 300, 200, "Banana");

        // aBev - instance of AlcoholicBeverage class 
        AlcoholicBeverage aBev = new AlcoholicBeverage("Vodka", 400, 50, "Highly alcoholic" );
   
        clrscr();
        
        /** 
         * main programm loop, designed to print menu and gives user ability to select a menu item
         * **/
        int menuItem = 0;
        boolean keeplooping = true;
        do {
                PrintMenu();
                menuItem=Genio.getInteger();   
                switch (menuItem) {
                    case 1:
                        bv1.PrintAttributes();
                        clearScreen();
                        break;
                    case 2:
                        mBev.PrintAttributes();
                        clearScreen();
                        break;
                    case 3:
                        aBev.PrintAttributes();
                        clearScreen();
                        break;
                    case 4:
                        keeplooping=false;
                        break;
                    default: 
                        System.out.println("Please enter a number from 1 to 4! ");
                        clearScreen();
                        break;
                }
        }while(keeplooping == true);
    }

    /** 
     * PrintMenu() - prints main programm menu, so user can chose what Beverage they would like to select
     * @return void
     * **/
    public static void PrintMenu(){
        System.out.println("");
        System.out.println("Assigment 4, Part 1: Beverage programm");
        System.out.println("-----------------------------------------------------------------------------------------------------------");
        System.out.println("");
        System.out.println("Main menu");
        System.out.println("1. Beverage details ");
        System.out.println("2. Milk Beverage details ");
        System.out.println("3. Alcoholic Beverage details ");
        System.out.println("4. Exit ");
        System.out.println("");
        System.out.print("Please select an option [1-4]: ");
    }

    /** 
     * This method was taken from the internet, it is used to clear the console screen
     * Source link: https://stackoverflow.com/questions/2979383/how-to-clear-the-console-using-java
     * @return void 
     * **/
    public static void clrscr(){
    //Clears Screen in java
    try {
        if (System.getProperty("os.name").contains("Windows")) {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        }
        else {
            System.out.print("\033\143");
        }
    } catch (IOException | InterruptedException ex) {}
    }

    /** 
     * clearScreen()  This method promts user to press 'y' to continue programm and clear the screen 
     * @return void
     * **/
    public static void clearScreen()
    {
        System.out.print("Enter 'y' to continue: ");
        char c; 
        do {
            c = Genio.getCharacter();
            clrscr();             
        } while (c != 'y');
    }

}
