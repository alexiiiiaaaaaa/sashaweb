
/**
 * Write a description of class Booking here.
 * 
 * @author
 * @version
 */
public class Booking
{
    private int bookingNumber;
    private boolean paid;
    private vehicle vehicle1;
    private Customer customer1;

    /**
     * Constructor for objects
     */
    public Booking()
    {
        // initialise instance variables
        bookingNumber = 0;
        paid = false;
    }
     
    /**main method
     * 
     */
      public static void main(String [] args)
    {
       Booking Booking1 = new Booking();
       Booking1.makeBooking();
    }

    /**
     * print booking details
     */
    public void printBooking()
    {
       System.out.println("##############################################");
       System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
       System.out.println("booking Details");
       customer1.printCustomer();
       System.out.println("vehicle details");
       vehicle1.printVehicle();
       System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
       System.out.println("payment details");
       System.out.println("cost of vehicle " + vehicle1.getCost());
       if (paid){
             System.out.println("balance paid ");
            }
            else {
                System.out.println("balance outstanding");
            }
        System.out.println("##############################################"); 
    }

    /**
     * place a booking 
     * 
     */
    public void makeBooking()
    {
        //create an instance of a vehicle
         vehicle1 = new vehicle();
        //check vehicle availability 
        if(vehicle1.getAvailable()== false)
        {
            System.out.println("Sorry but the vehicle is already on hire");
        }
        else 
        {
            System.out.println("Vehicle is available for hire");
            //call the method to get the customer details
            customerDetails();
            // sort out the payment
            payment();
            
            //print out booking details
            printBooking();
       }
       // set vehicle availability to false
       vehicle1.setAvailable(false);  
    }

    /**
     * input the customer details 
     */
    public void customerDetails()
    {
      // create a new instance of the customer class
        customer1 = new Customer();
        System.out.println("Please enter the customer number");
        int cusNum = Genio.getInteger(); 
        System.out.println("Please enter the customer name");
        String cusName = Genio.getString(); 
        System.out.println("Please enter the customer PostCode");
        String cusPC = Genio.getString(); 
        
        customer1.setCustomerNumber(cusNum);
        customer1.setCustomerName(cusName);
        customer1.setCustomerPostCode(cusPC);
    }

     /**
     * sort out the payment wiht the customer
     * set paid to true or false
     *
     */
    public void payment()
    {
        System.out.println("the cost of htis vehicle is �"+ vehicle1.getCost());
        System.out.println("has the customer paid? Y/N");
        String YN = Genio.getString();
        if (YN =="Y")
        {
            paid = true;
        }
        else 
        {
            paid = false;
        }
    }  
}
